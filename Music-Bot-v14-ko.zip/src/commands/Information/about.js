const { EmbedBuilder, ButtonBuilder, ActionRowBuilder, ButtonStyle } = require("discord.js");

module.exports = {
    name: "about",
    category: "Information",
    aliases: ["botinfo", "info"],
    description: "See information about this project.",
    args: false,
    usage: "",
    userPerms: [],
    owner: false,
    execute: async (message, args, client, prefix) => {
     
    const row = new ActionRowBuilder()
			.addComponents(
    new ButtonBuilder()
    .setLabel("Invite")
    .setStyle(ButtonStyle.Link)
    .setURL(`https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=36768832&scope=applications.commands%20bot`),
    new ButtonBuilder()
    .setLabel("GitHub")
    .setStyle(ButtonStyle.Link)
    .setURL("https://github.com/Trecox445/Moon-Music"),
    new ButtonBuilder()
    .setLabel("Support")
    .setStyle(ButtonStyle.Link)
    .setURL("https://discord.gg/TCWWccA7ms")
			);

      const mainPage = new EmbedBuilder()
            .setAuthor({ name: 'Moon Wave', iconURL: 'https://discord.com/channels/@me/989118695265693706/1027817405898043422'})
            .setThumbnail('https://discord.com/channels/@me/989118695265693706/1027817405898043422')
            .setColor(client.embedColor)
            .addFields([
                { name: 'Creator', value: '[Treo#1004](https://github.com/Trecox445)', inline: true },
                { name: 'Organization', value: '[Treo](https://github.com/Trecox445)', inline: true },
                { name: 'Repository', value: '[Here](https://github.com/Trecox445/Moon-Music/)', inline: true },
                { name: '\u200b', value: `[Moon Wave](https://github.com/Trecox445/Moon-Music-/) was created by [Trecox445](https://github.com/Trecox445). He really wanted to make his first open source project ever for more coding experience. In this project, he was challenged to make a project with less bugs. Hope you enjoy using Moon Wave!`, inline: true },
            ]);
        return message.reply({embeds: [mainPage], components: [row]});
    }
}
